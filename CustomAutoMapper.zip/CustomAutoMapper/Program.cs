﻿using Newtonsoft.Json;
using System;
using AutoMapper;

namespace CustomAutoMapper
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new Person()
            {
                FirstName = "Pesho",
                LastName = "Peshov",
                address = new Address()
                {
                    City = "Sofia",
                    Street = "Vitosha",
                    Number = 1
                }
            };

            var mapper = new Mapper();

            var student = mapper.CreateMappedObject<Student>(person);

            Console.WriteLine(JsonConvert.SerializeObject(student));
        }
    }
}
